#parse("Blank Header.java")
package ${PACKAGE_NAME};

import net.sf.hibernate.PersistentEnum;
import java.util.ArrayList;
import java.util.List;


public class ${Class_name} implements PersistentEnum {
#if (${Value_1} != "")
    public static final ${Class_name} ${Value_1.toUpperCase()} = new ${Class_name}(1, "${Value_1}");
#end
#if (${Value_2} != "")
    public static final ${Class_name} ${Value_2.toUpperCase()} = new ${Class_name}(2, "${Value_2}");
#end
#if (${Value_3} != "")
    public static final ${Class_name} ${Value_3.toUpperCase()} = new ${Class_name}(3, "${Value_3}");
#end
#if (${Value_4} != "")
    public static final ${Class_name} ${Value_4.toUpperCase()} = new ${Class_name}(4, "${Value_4}");
#end
#if (${Value_5} != "")
    public static final ${Class_name} ${Value_5.toUpperCase()} = new ${Class_name}(5, "${Value_5}");
#end
    
    private final int id;
    private final String description;
    
    public static ${Class_name} fromInt(int id) {
        switch (id) {
            case -1: return null;
        #if (${Value_1} != "")
            case 1: return ${Value_1.toUpperCase()};
        #end
        #if (${Value_2} != "")
            case 2: return ${Value_2.toUpperCase()};
        #end
        #if (${Value_3} != "")
            case 3: return ${Value_3.toUpperCase()};
        #end
        #if (${Value_4} != "")
            case 4: return ${Value_4.toUpperCase()};
        #end
        #if (${Value_5} != "")
            case 5: return ${Value_5.toUpperCase()};
        #end
            default: throw new RuntimeException("Unknown ${Class_name} id");
        }
    }

    public static int toInt(${Class_name} enum) {
        return (enum == null) ? -1 : enum.toInt();
    }
    
    public static List toList() {
        List list = new ArrayList();
    #if (${Value_1} != "")
        list.add(${Value_1.toUpperCase()});
    #end         
    #if (${Value_2} != "")
        list.add(${Value_2.toUpperCase()});
    #end         
    #if (${Value_3} != "")
        list.add(${Value_3.toUpperCase()});
    #end         
    #if (${Value_4} != "")
        list.add(${Value_4.toUpperCase()});
    #end         
    #if (${Value_5} != "")
        list.add(${Value_5.toUpperCase()});
    #end
        return list;         
    }
        
    private ${Class_name}(int id, String description) {
        this.id = id;
        this.description = description;
    }

    public int toInt() { return id; }
    
    public int getID() {
        return id;
    }
    
    public String getDescription() {
        return description;
    }
}