package ${PACKAGE_NAME};

public interface ${NAME} {
}
