package ${PACKAGE_NAME};

import static org.junit.Assert.*;
import org.junit.Test;


public class $Name {

    @Test
    public void () {

        fail("Not yet implemented");
    }
}
