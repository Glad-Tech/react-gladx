package org.studentloan.persistence.test;

import com.mockobjects.dynamic.Mock;
import org.studentloan.util.factory.MotherFactory;



public class Mock${ClassToMock} extends Mock {


    public static Mock${ClassToMock} prepareMock() {
        Mock${ClassToMock} mock = new Mock${ClassToMock}();
        MotherFactoryInvoker.setMock(${ClassToMock}.class, mock.proxyCasted());
        return mock;
    }


    private Mock${ClassToMock}() {
        super(${ClassToMock}.class);
    }


    public ${ClassToMock} proxyCasted() {
        return (${ClassToMock}) super.proxy();
    }

}
