@org.junit.Test
void test_${NAME}() {
${BODY}
}