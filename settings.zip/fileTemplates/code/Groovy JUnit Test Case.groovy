class ${NAME} {
  ${BODY}
}